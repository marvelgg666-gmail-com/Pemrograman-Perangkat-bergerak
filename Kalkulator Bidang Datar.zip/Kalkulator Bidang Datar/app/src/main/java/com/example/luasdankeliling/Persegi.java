package com.example.luasdankeliling;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Persegi extends AppCompatActivity {

    private EditText sisi;
    private TextView result_luas;
    private TextView result_keliling;
    private static final String TAG = "Persegi";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);

        //initialize
        sisi = (EditText) findViewById(R.id.sisi);
        result_luas = (TextView) findViewById(R.id.result_luas);
        result_keliling = (TextView)
                findViewById(R.id.result_keliling);
    }

    public void result(View view) {
        double sisi;
        try {
            sisi = getOperand(this.sisi);
        }
        catch (NumberFormatException e) {
            Log.d(TAG, "Error format..." + e);
            result_luas.setVisibility(View.VISIBLE);
            result_keliling.setVisibility(View.INVISIBLE);
            result_luas.setText(getString(R.string.computationError)); return;
        }

        String luas, keliling;
        luas = String.valueOf(sisi * sisi);
        keliling = String.valueOf(4 * sisi);

        result_luas.setVisibility(View.VISIBLE);
        result_keliling.setVisibility(View.VISIBLE);
        result_luas.setText("Luas: " + luas);
        result_keliling.setText("Keliling: " + keliling);
    }

    private static Double getOperand(EditText operandEditText) {
        String operandText = operandEditText.getText().toString();
        return Double.valueOf(operandText);
    }
}
